from flask_login import LoginManager
from flask_login import UserMixin
from flask import session ,jsonify

from . import db1



#class User(UserMixin, db.Model):
class User(UserMixin):
    
    def __init__ (self, user_json):
        self.user_json = user_json

    def get_id(self):
        object_id= self.user_json.get('_id')
        return str(object_id)
    def query(user_id):
        r=db1.users.find({ '_id': user_id})
        return r 


#fonction pour nettoyer le texte d'entrée
"""
def clean_text1(text):
     import re 
     from nltk.corpus import stopwords 
     from nltk.tokenize import word_tokenize 
     text= text.lower()
     #Supprimer les caractéres speciaux et les nombre
     text=re.sub(r'[\-\(\),]',' ',text)
     text=re.sub(r'[^a-zA-Z0-9\s\-_>ö]','',text)
     #Tokenization des mots                 
     tokens = word_tokenize(text)
     #Supprimer les stopwords 
     stop_words = list(stopwords.words('english'))
     stop_words1 = list(stopwords.words('french'))
     c=stop_words + stop_words1
     filtred_tokens=[token for token in tokens if token not in c]
      #Reconstituer le texte 
     text = " ".join(filtred_tokens)
     return text

#Nettoyage du fichier excel contenant les données de référence
def nettoyage_fichier_reference():
    import pandas as pd
    import re
    # Lecture du fichier Excel
    df = pd.read_excel(r"C:\Bureau\GLSI3\PFE\Maladies\mesDonneestoexcel.xlsx")

    # Suppression des colonnes vides
    df = df.dropna(axis=1, how='all')
    # Suppression des espaces en début et fin de chaque cellule
    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

    # Conversion des caractères en minuscules
    df = df.apply(lambda x: x.str.lower() if x.dtype == "object" else x)

    # Suppression des caractères spéciaux
    df['nom Maladie']  =df['nom Maladie'] .apply(lambda x: re.sub('-/', ' ', x))
    df = df.replace('[^\w\s\d,]','', regex=True)
    #Suppression des mots non significatifs
    df['nom Maladie']  =df['nom Maladie'] .apply(lambda x: re.sub(',', ' ', x))
    df['nom Maladie']  =df['nom Maladie'] .apply(lambda x: re.sub('susceptibility to|protection against|susceptibility|association with|progression of| modifier of| associated with', ' ', x))
    # Suppression des doublons
    df = df.drop_duplicates()
    # Création d'un nouveau fichier Excel sans les colonnes vides
    df.to_excel(r'C:\Bureau\GLSI3\PFE\excel_nettoye.xlsx', index=False)

#Fonction pour convertir les fichier pdf ,word en texte et stocker les données dans une chaine de caractère
def ConversionToText(fichier):
    import os 
    root,extension= os.path.splitext(fichier)
    if extension=='.pdf' :
        import PyPDF2
        from PyPDF2 import PdfFileReader
        #Creating a pdf file object
        pdf = open(fichier,"rb")
        #creating pdf reader object
        pdf_reader = PyPDF2.PdfReader(pdf)
        num_pages = len(pdf_reader.pages)
        res=[]
        for page_num in range(num_pages):
            page =pdf_reader.pages[page_num] 
            #pdf_reader.getPage(page_num)
            text = page.extract_text()
            res.append(text)
        pdf.close()
        return " ".join(res)
    elif extension == '.docx':
        from docx import Document
        #Creating a word file object
        doc = open(fichier,"rb")
        #creating word reader object
        document = Document(doc)
        docu=""
        for para in document.paragraphs:
            docu += para.text

        return docu
    elif extension == '.txt':
        newfile = open(fichier, "r",encoding='utf-8',errors='ignore')
        l=newfile.readlines()
        return "".join(l)
    else:
        print("Error:type de fichier non reconnu")
        return " "
        
#Récupération des données de référence du fichier excel (nom maladie , nom gène et la localisation du gène)
def donneeReference():
    import pandas as pd
    # Lecture du fichier Excel
    #df = pd.read_excel('C:\Bureau\GLSI3\PFE\excel_nettoye.xlsx')
    df = pd.read_excel('excel_nettoye.xlsx')
    genetic_diseases={}
    gene_names=[]
    gene_location=[]
    # Parcours des lignes du fichier Excel
    for index, row in df.iterrows():
        # Extraction du texte à nettoyer
        if(not isinstance(row['nom Maladie'], float)):
            maladies = row['nom Maladie']
            maladies=clean_text1(maladies)
            gen=row['nom Gene'].lower()
            genes=gen.split(",")
            location=row['localisation gene']
            genetic_diseases[maladies] = genes
            for i in genes:
                if i not in gene_names:
                    gene_names.append(i)
            if location not in gene_location:
                gene_location.append(location)
    return genetic_diseases,gene_names,gene_location


#fonction pour detecter les maladies, gènes , numero omim ,etc
def detection1(text):
    import nltk
    import re
    import spacy 
    nlp = spacy.load("en_core_sci_sm")
    genetic_diseases,gene_names,gene_location=donneeReference()
    #Nettoyer le texte 
    text = clean_text1(text)
    #Analyse du texte avec spacy 
    doc = nlp(text)

    localisation=[]
    disease_names = set()
    gene_symbols = set()
    for entity in doc.ents:
        if entity.text in genetic_diseases:
            disease_names.add(entity.text)
            #genes+=genetic_diseases[entity.text]
        elif entity.text in gene_names: 
            gene_symbols .add(entity.text)
        elif entity.text in gene_location: 
            localisation.append(entity.text)

    #expression régulière numero omim
    omim_regex=re.compile(r"\b(omim|mim)\s*\d+\b")
    # expressions régulières pour les maladies
    disease_regex2= re.compile(r"\b(\w+(\-\w+)?\s+){1,4}([genetic]?\s+disease|[genetic]?\s+disorder)\b")
    disease_regex1 = re.compile(r"(r'\b(syndrome|desease|affection)\b\s+\b(\w+)\b\s+\b(genetic|chromosomique|heredity)\b', re.IGNORECASE)")
    disease_regex3 = re.compile(r"(\w+\s+){2,4}([common|uncommon\srare|uncommon]?\s+congenital[s]?\s+[malformation[s]?|abnormality])")
    disease_regex4 = re.compile(r"(\w+\s+)syndrome")
    disease_regex5 = re.compile(r"(r'\b(autosomal\sdominant|autosomal\srecessive|hypomorphic|hypermorphic)\s\w+\b')")
    disease_regex7=re.compile(r"((\w+\s+){2,4})(condition\s+characterized\s+congenital|systemic\s+vascular\s+disease|sys.?temic\s+vascular\s+disease|rare\s+genodermatosis\s+caused\s+mutations)")
     
    #Expressions régulières pour les gènes
    
    #gene_regex1= re.compile(r"\b([A-Z]\w*(?=\s\(|-))(?:\s\(|-)\w+|\b([A-Z]{2,})(?=\s|$)")
    #gene_regex3= re.compile(r"(r'\b(?:[A-Z]{2,}\d+(?:-\d+)*|[A-Z]{3,})\b')")
    regex_genes1 = re.compile(r"\b([a-z]{2,}[0-9]*)\s(?:gene[s]?|protein[s]?|molecule[s]?|factor[s]?)\b")
    
    #localtion gene
    regex_localisation = re.compile(r"(?:chromosome[s]?\s|chromo[s]?\s)(?:\s[A-Z]{1}[a-z]+\s)?\d[a-z]?\d*")
    localisation = regex_localisation.findall(text)
    #Nettoyer le text
    text=clean_text1(text)

    #doc=nlp(text)
    #matching for omim number
    omim=""
    if omim_regex.search(text):
        omim=omim_regex.search(text).group(0)
    #Matching for the diseases
    if disease_regex1.search(text):
        disease_names.add(disease_regex1.search(text).group(0))
    if disease_regex2.search(text):
        disease_names.add(disease_regex2.search(text).group(1))
    if disease_regex3.search(text):
        disease_names.add(disease_regex3.search(text).group(1))
    if disease_regex4.search(text):
        disease_names.add(disease_regex4.search(text).group(0))
    if disease_regex5.search(text):
        disease_names.add(disease_regex5.search(text).group(0))
    if disease_regex7.search(text):
        disease_names.add(disease_regex7.search(text).group(1))

    #Matching for the genes
    if regex_genes1.search(text):
        gene_symbols.add(regex_genes1.search(text).group(1))

    # Print the results
    return {"omim":omim,"disease":", ".join(list(set(disease_names))),"genes":", ".join(list(set(gene_symbols))),"location":", ".join(list(set(localisation)))}
    
"""
