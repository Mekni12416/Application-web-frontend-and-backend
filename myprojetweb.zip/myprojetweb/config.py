from app import create_app
app = create_app()
app.config['SECRET_KEY'] = b'8e7d3bf1c1bcb2b0ac747b8f64cd682516a0d392875107a8'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024 # 16MB

import pymongo 
client = pymongo.MongoClient('localhost',27017)
db1= client.livraison_system 