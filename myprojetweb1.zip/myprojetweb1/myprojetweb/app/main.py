from flask import Blueprint , render_template , session , redirect ,request , url_for,jsonify,flash
from flask_login import login_required, current_user
from . import db1
from werkzeug.utils import secure_filename
from .models import * 
import os
main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index1.html')

@main.route('/categories1')
def categories1():
    return render_template('categories1.html')

