
from app import create_app
create_app().run(debug=True)


#import secrets

# Générer une clé secrète aléatoire de 24 caractères
#secret_key = secrets.token_hex(24)
#print(secret_key)